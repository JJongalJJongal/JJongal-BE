from fastapi import FastAPI
from enum import Enum
from starlette.middleware.cors import CORSMiddleware

from fastapi.responses import FileResponse

from board import board_router
from user import user_router
from oauth import social_router

import models 
import os #
from dotenv import load_dotenv #
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

from database import engine
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(board_router.app, tags=["board"])
app.include_router(user_router.app, tags=["user"])
app.include_router(social_router.app, tags=["oauth"])

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    #return {"Hello": "World"}
    test_env = os.environ["TEST_ENV"]
    return {"result": test_env}

'''
GOOGLE_CLIENT_ID = '838753567973-rmf25hksv8vstdsu1bp50uhvookrtcda.apps.googleusercontent.com'
GOOGLE_CLIENT_SECRET = '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'
GOOGLE_CALLBACK_URI = 'http://127.0.0.1:5500/google/callback.html'

KAKAO_CLIENT_ID = 'e18cca4d0e6b12e3d8ad648ced2d5a6e'
KAKAO_SECRET = 'e18cca4d0e6b12e3d8ad648ced2d5a6e'
KAKAO_CALLBACK_URI = "http://127.0.0.1:5500/kakao/callback.html"

NAVER_CLIENT_ID = 'KozFMic3TK7NSVNHaChL'
NAVER_SECRET = 'HJvX9FSwME'
NAVER_CALLBACK_URI = "http://127.0.0.1:5500/naver/callback.html"
'''